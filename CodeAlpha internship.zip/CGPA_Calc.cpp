#include <iostream>
#include <string>
#include <iomanip>
#include <limits>
#include <fstream>
#include <vector>
using namespace std;

struct Course {
    string name;
    float credit_hours;
    string grade;
};

double gradeToGpa(string grade) {
    if (grade == "A") return 4.0;
    if (grade == "A-") return 3.7;
    if (grade == "B+") return 3.4;
    if (grade == "B") return 3.2;
    if (grade == "B-") return 2.8;
    if (grade == "C+") return 2.5;
    if (grade == "C") return 2.2;
    if (grade == "C-") return 1.8;
    if (grade == "D+") return 1.5;
    if (grade == "D") return 1.2;
    if (grade == "F") return 0.0;
    return -1;
}

double calculateSemesterGPA(const vector<Course>& courses) {
    double total_credits = 0, total_credit_points = 0;
    for (const auto& course : courses) {
        double grade_points = gradeToGpa(course.grade);
        total_credit_points += grade_points * course.credit_hours;
        total_credits += course.credit_hours;
    }
    return total_credits > 0 ? total_credit_points / total_credits : 0;
}

int main() {
    ofstream file("student_results.txt", ios::app);
    if (!file) {
        cout << "Error while writing to file..." << endl;
        return 1;
    }

    int no_students;
    cout << "Enter the number of students: ";
    while (!(cin >> no_students) || no_students <= 0) {
        cout << "Invalid Input! Enter a valid numeric value..." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    for (int i = 1; i <= no_students; i++) {
        double cumulative_credits = 0, cumulative_grade_point = 0;
        cout << "\nEnter the details for student " << i << ":\n";

        string student_name;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Enter Student Name: ";
        getline(cin, student_name);

        file << "===============================\n";
        file << "Student " << i << ": " << student_name << "\n";

        int semesters;
        cout << "Enter the number of semesters: ";
        while (!(cin >> semesters) || semesters <= 0) {
            cout << "Invalid Input! Enter a valid numeric value..." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        for (int sem = 1; sem <= semesters; sem++) {
            int numCourses;
            double total_credits = 0;
            
            cout << "\nEnter number of courses for semester " << sem << ": ";
            while (!(cin >> numCourses) || numCourses <= 0) {
                cout << "Invalid Input! Enter a valid numeric value..." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            
            vector<Course> courses(numCourses);
            file << "  Semester " << sem << ":\n";
            
            for (int j = 0; j < numCourses; j++) {
                cout << "\nEnter details for Course " << j + 1 << ":\n";
                cout << "Course Name: ";
                getline(cin, courses[j].name);

                cout << "Credit Hours: ";
                while (!(cin >> courses[j].credit_hours) || courses[j].credit_hours <= 0) {
                    cout << "Invalid Input! Enter a valid numeric value..." << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
                
                cout << "Course Grade (A / A- / B+ / B / B- / C+ / C / C- / D+ / D / F): ";
                getline(cin, courses[j].grade);
                
                while (gradeToGpa(courses[j].grade) == -1) {
                    cout << "Invalid Grade. Please enter a valid grade: ";
                    getline(cin, courses[j].grade);
                }
                total_credits += courses[j].credit_hours;
                
                file << "    " << left << setw(20) << courses[j].name << " (" << courses[j].credit_hours << " credits) - Grade: " << courses[j].grade << "\n";
            }

            double semester_gpa = calculateSemesterGPA(courses);
            cout << "Semester GPA: " << fixed << setprecision(2) << semester_gpa << endl;
            file << "  Semester GPA: " << fixed << setprecision(2) << semester_gpa << "\n";

            cumulative_grade_point += semester_gpa * total_credits;
            cumulative_credits += total_credits;
        }

        double CGPA = cumulative_credits > 0 ? cumulative_grade_point / cumulative_credits : 0;
        cout << "Final CGPA: " << fixed << setprecision(2) << CGPA << endl;
        file << "Final CGPA: " << fixed << setprecision(2) << CGPA << "\n";
        file << "===============================\n\n";
    }

    file.close();
    cout << "\nResults have been saved to 'student_results.txt'.\n";
    return 0;
}